function pred_pm2d5 = pm2d5_pred_model(trainData, testData, problemType)
    % this function is the main function
    % train data is a table
    % just for the evaluation. segregate test data input (time,
    % location) from pm2d5
    
    % Retime the data to occur at regular 3-second intervals, and fill in
    % missing values.

    diferences = diff(trainData.time);
    idx = find(diferences<0);
    idx = [0; idx; size(trainData, 1)];
    cleanedData = [];
    for i = 1:length(idx)-1

        firstFilledData = fillEmpty(trainData(idx(i)+1:idx(i+1),:));
        
        % Denoise the retimed data.
        % 'option' is either "fourier" or the wavelet code for the mother wavelet
        % denoising, in single quotes: ' '
        option = 'db1';
 
        firstFilledData.pm2d5 = denoise(firstFilledData.pm2d5, problemType, option, 3);
        % db1 is the best for temp looking at the data plot.
        firstFilledData.tmp = denoise(firstFilledData.tmp, problemType, 'db1', 3);
        firstFilledData.hmd = denoise(firstFilledData.hmd, problemType, option, 3);
        firstFilledData.spd = denoise(firstFilledData.spd, problemType, option, 3);
        % set the gaussian process time window interval, might be good to
        % have it different for different problems
        if problemType == 3
            timeInterval = 60; % winds up being the best to keep at 60mins like the others
        else 
            timeInterval = 60;
        end
        min_filled = sec2FiveMin(firstFilledData, timeInterval);
        cleanedData = [cleanedData; min_filled];
    end

    % run model with cleaned and filled data
    pred_pm2d5 = getModel(cleanedData, testData, 'gaussianProcess');
    
end
